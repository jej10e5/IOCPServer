#pragma once
#include "pch.h"
constexpr UINT16 PACKET_ID_ECHO = 1;

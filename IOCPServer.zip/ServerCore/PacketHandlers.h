#pragma once
#include "pch.h"
class Session;

void Handle_Eco(Session* _pSession, const char* _pData, UINT16 _ui16size);
